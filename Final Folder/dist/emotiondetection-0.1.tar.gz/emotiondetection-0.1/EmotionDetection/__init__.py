import json
import requests
from . import emotion_detection